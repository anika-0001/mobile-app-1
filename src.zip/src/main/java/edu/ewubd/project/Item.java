package edu.ewubd.project;

public class Item {
    String key = "";
    String iname = "";
    String iqunat = "";
    String iup = "";
    public Item(String key,String iname,String iqunat,String iup){
        this.key = key;
        this.iname = iname;
        this.iqunat = iqunat;
        this.iup = iup;
    }
}
