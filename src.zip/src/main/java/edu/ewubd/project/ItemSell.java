package edu.ewubd.project;

public class ItemSell {
    String key = "";
    String iname = "";
    String iqunat = "";
    String iup = "";
    String st = "";
    String time = "";
    public ItemSell(String key, String iname, String iqunat, String iup, String st, String time){
        this.key = key;
        this.iname = iname;
        this.iqunat = iqunat;
        this.iup = iup;
        this.st = st;
        this.time = time;
    }
}